# AutoFlow — Advanced Plug-and-Play Repo (All Services)

This repository is a plug-and-play scaffold for the **AutoFlow** product:
Content Writer, Image Generator, and Automation Workflows — with Stripe billing,
Postgres (Prisma) schema, and deployment configs for Render & Vercel.

## What this ZIP contains
- `backend/` — Node backend scaffold (Fastify/Express-style), Stripe + OpenAI stubs
- `frontend/` — Vite + React minimal app with pages for Content, Image, Automations
- `infra/` — deployment config samples for Render & Vercel
- `.env.example` files with placeholders

⚠️ **Important:** This scaffold uses placeholders and a file-based stub DB for demo only.
Replace with real secrets and a managed Postgres (Supabase/Neon) before production.
