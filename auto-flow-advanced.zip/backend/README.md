# Backend (AutoFlow) - Quick Start

1. Copy `.env.example` to `.env` and fill environment variables.
2. Install deps: `npm install`
3. Run dev: `npm run dev` (requires nodemon) or `npm start`

This backend is a scaffold/demo. Replace the file-based users.json persistence with Postgres/Prisma for production.
