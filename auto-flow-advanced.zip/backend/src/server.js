require('dotenv').config();
const express = require('express');
const cors = require('cors');
const Stripe = require('stripe');
const fetch = (...args) => import('node-fetch').then(({default:fetch})=>fetch(...args));
const fs = require('fs');
const path = require('path');

const app = express();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_dummy');
const PORT = process.env.PORT || 3000;
const FRONTEND = process.env.FRONTEND_URL || 'http://localhost:5173';

app.use(cors({ origin: FRONTEND }));
app.use(express.json());

const USERS_FILE = path.join(__dirname, '..', 'data', 'users.json');
function readUsers(){ try { return JSON.parse(fs.readFileSync(USERS_FILE)); } catch(e) { return { users: [] }; } }
function writeUsers(data){ fs.mkdirSync(path.dirname(USERS_FILE), { recursive: true }); fs.writeFileSync(USERS_FILE, JSON.stringify(data,null,2)); }

app.get('/', (req,res)=> res.send('AutoFlow backend (stub)'));

// Content generation (server-side OpenAI proxy)
app.post('/api/content/generate', async (req,res) => {
  const { prompt, email } = req.body;
  if(!prompt) return res.status(400).json({ error: 'prompt required' });
  // Simple gating: check subscription status in users.json (demo only)
  if(!email) return res.status(401).json({ error: 'email required' });
  const db = readUsers();
  const user = db.users.find(u=>u.email===email && u.subscription_status==='active');
  if(!user) return res.status(403).json({ error: 'no active subscription (demo)' });

  try {
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 800
      })
    });
    const data = await resp.json();
    const text = data?.choices?.[0]?.message?.content || JSON.stringify(data);
    res.json({ result: text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Image generation (stub)
app.post('/api/image/generate', async (req,res) => {
  const { prompt, email } = req.body;
  if(!prompt) return res.status(400).json({ error: 'prompt required' });
  // Demo response - implement provider calls (OpenAI Images / Stable Diffusion) in production
  res.json({ result: 'image_generated_placeholder.png', prompt });
});

// Automation run (stub)
app.post('/api/automation/run', async (req,res) => {
  const { flow, email } = req.body;
  if(!flow) return res.status(400).json({ error: 'flow required' });
  // In production this should enqueue a job and orchestrate steps.
  res.json({ status: 'queued', flow });
});

// Create Stripe Checkout session
app.post('/api/create-checkout-session', async (req,res) => {
  const { priceId, email } = req.body;
  const usedPrice = priceId || process.env.STRIPE_PRICE_ID;
  if(!usedPrice) return res.status(400).json({ error: 'priceId required' });
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: usedPrice, quantity: 1 }],
      customer_email: email,
      success_url: `${FRONTEND}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${FRONTEND}/cancel`
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Simple endpoint to check subscription (demo)
app.get('/api/me', (req,res) => {
  const { email } = req.query;
  if(!email) return res.status(400).json({ error: 'email required' });
  const db = readUsers();
  const user = db.users.find(u=>u.email===email);
  if(!user) return res.json({ subscription_status: 'none' });
  res.json({ subscription_status: user.subscription_status, details: user });
});

// Stripe webhook (raw body)
app.post('/webhook', express.raw({ type: 'application/json' }), (req,res) => {
  const sig = req.headers['stripe-signature'];
  if(!process.env.STRIPE_WEBHOOK_SECRET) return res.status(400).send('Webhook secret not configured');
  try {
    const event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    console.log('Webhook event:', event.type);
    if(event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const email = session.customer_email;
      const subscriptionId = session.subscription;
      const db = readUsers();
      let user = db.users.find(u=>u.email===email);
      if(!user) {
        user = { email, stripe_customer: session.customer, subscription_id: subscriptionId, subscription_status: 'active', created: new Date().toISOString() };
        db.users.push(user);
      } else {
        user.subscription_id = subscriptionId;
        user.subscription_status = 'active';
        user.stripe_customer = session.customer;
      }
      writeUsers(db);
      console.log('Activated:', email);
    }
    // other event handlers omitted for brevity
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook error', err.message);
    res.status(400).send(`Webhook error: ${err.message}`);
  }
});

app.listen(PORT, ()=> console.log(`AutoFlow backend running on ${PORT}`));
