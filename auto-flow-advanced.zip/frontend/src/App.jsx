import React, { useState } from 'react';
const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

export default function App(){
  const [email, setEmail] = useState('');
  const [prompt, setPrompt] = useState('Write a short marketing email for Acme Widgets.');
  const [output, setOutput] = useState('');
  const [loading, setLoading] = useState(false);

  async function runContent(){
    setLoading(true); setOutput('');
    const res = await fetch(`${API_BASE}/api/content/generate`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ prompt, email })
    });
    const data = await res.json();
    setOutput(data.result || JSON.stringify(data));
    setLoading(false);
  }

  async function checkout(){
    const res = await fetch(`${API_BASE}/api/create-checkout-session`, {
      method: 'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    if(data.url) window.location.href = data.url;
    else alert('Checkout error: ' + JSON.stringify(data));
  }

  return (
    <div style={{padding:20, fontFamily: 'Inter, sans-serif', maxWidth:900, margin:'0 auto'}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>AutoFlow — Demo</h1>
        <button onClick={checkout} style={{padding:'8px 12px'}}>Buy subscription</button>
      </header>

      <section style={{marginTop:20}}>
        <label><strong>Your email (used for gating)</strong></label>
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" style={{width:'100%', padding:8, marginTop:8}}/>

        <div style={{marginTop:12}}>
          <label><strong>Prompt</strong></label>
          <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={6} style={{width:'100%', padding:12}}/>
          <div style={{marginTop:8}}>
            <button onClick={runContent} disabled={loading || !email} style={{padding:'8px 12px'}}>{loading ? 'Running...' : 'Run Content'}</button>
          </div>
        </div>

        <div style={{marginTop:16}}>
          <h3>Output</h3>
          <pre style={{background:'#f3f4f6', padding:12}}>{output || 'No output yet.'}</pre>
        </div>
      </section>
    </div>
  );
}
