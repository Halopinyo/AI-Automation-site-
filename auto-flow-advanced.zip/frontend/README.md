# Frontend (AutoFlow) - Quick Start

1. Copy `.env.example` to `.env` and adjust `VITE_API_BASE_URL` if needed.
2. Install deps: `npm install`
3. Run dev: `npm run dev` (Vite default port 5173)
