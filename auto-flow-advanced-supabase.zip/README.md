# AutoFlow — Supabase/Postgres-ready ZIP

This scaffold is an upgraded plug-and-play repo for AutoFlow with Postgres (Supabase) integration using Prisma.

## Quick overview
- `backend/` — Express backend using Prisma to persist users and subscription status.
- `frontend/` — Vite + React demo app (same as previous).
- `.env.example` files included.

**Important:** Replace placeholders with your actual Supabase DATABASE_URL and Stripe keys before running.

## Quick local run (backend)
1. Install dependencies:
   ```
   cd backend
   npm install
   ```
2. Copy `.env.example` to `.env` and fill `DATABASE_URL`, `OPENAI_API_KEY`, and Stripe keys.
3. Run Prisma migrate (this will create tables):
   ```
   npx prisma migrate dev --name init
   ```
4. Start the server:
   ```
   npm run dev
   ```

## Deploy
- Push to GitHub and deploy backend to Render (or Railway) and frontend to Vercel.
- Add environment variables in Render:
  - DATABASE_URL (Supabase connection string)
  - OPENAI_API_KEY
  - STRIPE_SECRET_KEY
  - STRIPE_WEBHOOK_SECRET
  - STRIPE_PRICE_ID
  - FRONTEND_URL
