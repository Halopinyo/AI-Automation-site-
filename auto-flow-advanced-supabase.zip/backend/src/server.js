require('dotenv').config();
const express = require('express');
const cors = require('cors');
const Stripe = require('stripe');
const fetch = (...args) => import('node-fetch').then(({default:fetch})=>fetch(...args));
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const app = express();
const stripe = Stripe(process.env.STRIPE_SECRET_KEY || 'sk_test_dummy');
const PORT = process.env.PORT || 3000;
const FRONTEND = process.env.FRONTEND_URL || 'http://localhost:5173';

app.use(cors({ origin: FRONTEND }));
app.use(express.json());

// Health
app.get('/', (req,res)=> res.send('AutoFlow backend (Prisma + Supabase demo)'));

// Content generation (server-side OpenAI proxy) - requires subscription
app.post('/api/content/generate', async (req,res) => {
  const { prompt, email } = req.body;
  if(!prompt) return res.status(400).json({ error: 'prompt required' });
  if(!email) return res.status(401).json({ error: 'email required' });
  try {
    const user = await prisma.user.findUnique({ where: { email }});
    if(!user || user.subscriptionStatus !== 'active') return res.status(403).json({ error: 'no active subscription' });

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 800
      })
    });
    const data = await response.json();
    const text = data?.choices?.[0]?.message?.content || JSON.stringify(data);
    res.json({ result: text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Image generation (stub) - requires subscription
app.post('/api/image/generate', async (req,res) => {
  const { prompt, email } = req.body;
  if(!prompt) return res.status(400).json({ error: 'prompt required' });
  if(!email) return res.status(401).json({ error: 'email required' });
  const user = await prisma.user.findUnique({ where: { email }});
  if(!user || user.subscriptionStatus !== 'active') return res.status(403).json({ error: 'no active subscription' });

  // TODO: integrate with OpenAI images / Stable Diffusion provider
  res.json({ result: 'image_placeholder.png', prompt });
});

// Automation run (stub) - requires subscription
app.post('/api/automation/run', async (req,res) => {
  const { flow, email } = req.body;
  if(!flow) return res.status(400).json({ error: 'flow required' });
  if(!email) return res.status(401).json({ error: 'email required' });
  const user = await prisma.user.findUnique({ where: { email }});
  if(!user || user.subscriptionStatus !== 'active') return res.status(403).json({ error: 'no active subscription' });

  // In production this should enqueue a job and orchestrate steps.
  res.json({ status: 'queued', flow });
});

// Create Stripe Checkout session
app.post('/api/create-checkout-session', async (req,res) => {
  const { priceId, email } = req.body;
  const usedPrice = priceId || process.env.STRIPE_PRICE_ID;
  if(!usedPrice) return res.status(400).json({ error: 'priceId required' });
  try {
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      payment_method_types: ['card'],
      line_items: [{ price: usedPrice, quantity: 1 }],
      customer_email: email,
      success_url: `${FRONTEND}/success?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${FRONTEND}/cancel`
    });
    res.json({ url: session.url });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

// Simple endpoint to check subscription status
app.get('/api/me', async (req,res) => {
  const { email } = req.query;
  if(!email) return res.status(400).json({ error: 'email required' });
  const user = await prisma.user.findUnique({ where: { email }});
  if(!user) return res.json({ subscription_status: 'none' });
  res.json({ subscription_status: user.subscriptionStatus, details: user });
});

// Stripe webhook (raw body) - persists subscription state using Prisma
app.post('/webhook', express.raw({ type: 'application/json' }), async (req,res) => {
  const sig = req.headers['stripe-signature'];
  if(!process.env.STRIPE_WEBHOOK_SECRET) return res.status(400).send('Webhook secret not configured');
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature error', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  try {
    if(event.type === 'checkout.session.completed') {
      const session = event.data.object;
      const email = session.customer_email;
      const subscriptionId = session.subscription;
      await prisma.user.upsert({
        where: { email },
        update: { subscriptionStatus: 'active', stripeCustomerId: session.customer, subscriptionId },
        create: { email, subscriptionStatus: 'active', stripeCustomerId: session.customer, subscriptionId }
      });
      console.log('User activated:', email);
    }

    if(event.type === 'invoice.payment_failed') {
      const invoice = event.data.object;
      const subId = invoice.subscription;
      await prisma.user.updateMany({
        where: { subscriptionId: subId },
        data: { subscriptionStatus: 'past_due' }
      });
    }

    if(event.type === 'customer.subscription.deleted') {
      const sub = event.data.object;
      const subId = sub.id;
      await prisma.user.updateMany({
        where: { subscriptionId: subId },
        data: { subscriptionStatus: 'canceled' }
      });
    }
  } catch(err) {
    console.error('Error handling webhook:', err);
  }

  res.json({ received: true });
});

app.listen(PORT, ()=> console.log(`AutoFlow backend running on ${PORT}`));
