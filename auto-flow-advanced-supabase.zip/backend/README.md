# Backend (AutoFlow) - Supabase/Postgres + Prisma

1. Copy `.env.example` to `.env` and fill `DATABASE_URL` (Supabase connection string), OPENAI_API_KEY, STRIPE keys.
2. Install deps:
   ```
   cd backend
   npm install
   ```
3. Initialize Prisma client and run migration:
   ```
   npx prisma generate
   npx prisma migrate dev --name init
   ```
4. Start server:
   ```
   npm run dev
   ```

Notes:
- This setup uses Prisma to persist users and subscription status from Stripe webhooks.
- For production, run migrations in CI/CD or use `prisma migrate deploy`.
